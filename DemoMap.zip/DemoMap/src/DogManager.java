
import java.util.Collection;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class DogManager {
    private HashMap<Integer, Dog> h;
    public DogManager () {
        h=new HashMap<>();
    }
    
    public void addDog(Dog d){
        h.put(d.getId(), d);
    }
    
    public void displayAllDogs(){
        Collection<Dog> result = h.values();
        for (Dog dog : result) {
            System.out.println(dog);
        }
    }
    
    public void displayAllKeys(){
        Set<Integer> key = h.keySet();
        for (int id : key) {
            System.out.print(id+"-");
            System.out.println(h.get(id));
        }
    }
    
    public void updateDog(int id){
        Dog d = h.get(id);
        if (d!= null){
            Scanner s = new Scanner(System.in);
            System.out.println("Enter new name: ");
            d.setName(s.nextLine());
        }
        else System.out.println("Not found");
    }
    
    public void removeDog(int id){
        h.remove(id);
    }
}
