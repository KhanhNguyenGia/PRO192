/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class tester {
    public static void main(String[] args) {
        DogManager m = new DogManager();
        m.addDog(new Dog(1, "lulu"));
        m.addDog(new Dog(2, "vang"));
        m.addDog(new Dog(3, "den"));
        m.addDog(new Dog(1, "bo"));
        m.displayAllDogs();
        m.displayAllKeys();
    }
}
